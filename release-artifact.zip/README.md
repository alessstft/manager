# Cоздание веб-приложения для управления проектами и задачами с использованием Python и Django

## Главная страница 
**Регистрация - для администраторов,**
**Вход - для подчиненных**
![image](https://github.com/user-attachments/assets/9730be56-74fe-4da9-bb1b-a5091f7a5e46)
![image](https://github.com/user-attachments/assets/de96270c-344c-4362-ba58-744e9317eff1)


## Функции ***администратора***

Администратор заведует полностью всем, что происходит на сайте.

В первую очередь он регистрируется сам:
![image](https://github.com/user-attachments/assets/9abdba52-5ea1-4fa5-ad19-adf1a208bbd6)

Дальше регистрирует новых работников, дает им логин и пароль для доступа к их аккаунту.
![image](https://github.com/user-attachments/assets/52a43ef3-8d3a-4e88-a1e7-9e4d0714121d)
![image](https://github.com/user-attachments/assets/25ab201a-eb8d-4b77-8a73-add2522a6f77)

Например:
![image](https://github.com/user-attachments/assets/2bf4bfe2-9bac-421f-b1b6-86d169498378)
![image](https://github.com/user-attachments/assets/4e054e24-27bf-4226-9aa5-4e67a50d5ebd)

и легко может вернуться к сайту в любой момент
![Frame 23](https://github.com/user-attachments/assets/3d184fb9-5fc6-4d82-8dd7-2ebce2b005c6)



## Функции для ***пользователя***

По данным, которые дает админ, пользователь входит в свой аккаунт.

![image](https://github.com/user-attachments/assets/771108c2-1de8-493d-a15b-ca6de3002939)

 Пользователь может сам добавлять себе задачи, прописывать детали, оставлять для них комментарии, загружать файлы, видеть историю этой задачи.
 
![image](https://github.com/user-attachments/assets/6bcf56b6-a193-4bc6-b9a4-4797ce3686f6)

![image](https://github.com/user-attachments/assets/b5b173b0-3e66-4e9f-88de-dc51e3858f05)

![image](https://github.com/user-attachments/assets/43dbce54-ea74-440e-a8ae-72bb71715e96)

![image](https://github.com/user-attachments/assets/da16d266-99e1-4e49-92a8-e997a7aa1a8f)

Можно отслеживать свои проекты и проекты других

![image](https://github.com/user-attachments/assets/7961b43b-c20d-4cbe-99ca-ab00e4c9843d)


а также добавлять новые проекты

![image](https://github.com/user-attachments/assets/b504feaa-7234-4096-aee4-fa26bf35fba5)

и редактировать уже созданные поекты

![image](https://github.com/user-attachments/assets/9c32e596-33e4-4f5e-a9ce-d45c405e308d)

## Быстрый запуск (локально)

1. Установите Python 3.12+.
2. Установите зависимости:

```bash
pip install -r requirements.txt
```

3. Выполните миграции:

```bash
python tasks/manage.py migrate
```

4. Запустите сервер:

```bash
python tasks/manage.py runserver
```

Приложение будет доступно по адресу `http://127.0.0.1:8000/`.

## Тестирование и сборка

- Локальный запуск тестов:
  - `python tasks/manage.py test new users`
- Проверка, что миграции актуальны:
  - `python tasks/manage.py makemigrations --check --dry-run`
- CI запускается через GitHub Actions из файла `.github/workflows/ci.yml` и выполняет:
  - установку зависимостей;
  - проверку миграций;
  - автоматические тесты;
  - сборку ZIP-артефакта релиза.

## Документация кода (Doxygen)

Для генерации документации используется файл `Doxyfile` и Doxygen-совместимые комментарии в Python-коде.

```bash
doxygen Doxyfile
```

HTML-документация будет создана в каталоге `docs/doxygen/html`.

## Инструкция по выпуску релиза

1. Убедитесь, что тесты проходят:
   - `python tasks/manage.py test new users`
2. Создайте ZIP-артефакт (локально):
   - `git archive --format=zip --output=release-artifact.zip HEAD`
3. Создайте тег:
   - `git tag vX.Y.Z`
4. Опубликуйте релиз с артефактом:
   - `gh release create vX.Y.Z release-artifact.zip --title "vX.Y.Z" --notes "Release vX.Y.Z"`
